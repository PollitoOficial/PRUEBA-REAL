import React from 'react'

export default function App() {
  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>Hola desde React + Vite</h1>
    </div>
  )
}